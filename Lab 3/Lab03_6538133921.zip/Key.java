public class Key {
    private String keyID;
    public Key(String keyID) {
        this.keyID = keyID;
    }

    public String getKeyID() {
        return keyID;
    }
}
